# Dice-Roller
This is a Dice Roller App made on Android Studio using Kotlin that shows random numbers from 1 to 6 on every dice roll

![alt text](https://github.com/Vinayakbora/Dice-Roller/blob/main/Dice.jpg)
